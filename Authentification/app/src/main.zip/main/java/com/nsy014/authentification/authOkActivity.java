package com.nsy014.authentification;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class authOkActivity extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.auth_ok); // associe la vue correspondante
        String logRecup = getIntent().getExtras().getString("login", "Prob ?");
        TextView authOk = (TextView)findViewById(R.id.auth_ok);
        authOk.setText("Bravo " + logRecup);
    }
}
